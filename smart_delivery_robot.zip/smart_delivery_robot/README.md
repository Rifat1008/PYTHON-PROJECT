# Smart Delivery Robot – Pathfinding System (Part 1 of 2: Core + Algorithms)

## Status
DONE: grid model, terrain costs, all 5 algorithms, metrics, console test/demo,
      Pygame window with search animation + moving robot + mouse map editing + results/compare panel.
TODO (polish): speed control, extra icons/sounds, more presentation features.

## Run
    pip install pygame
    python main.py            (GUI: animated search + robot)
    python demo.py            (terminal demo)
    python test_algorithms.py (tests, no pygame needed)

## Structure
    core/grid_model.py     shared Grid (terrain, start, goal, neighbors)  - everyone
    algorithms/bfs.py, dfs.py        - Member 1
    algorithms/ucs.py                - Member 2
    algorithms/greedy.py, astar.py   - Member 3
    utils/metrics.py       run_algorithm(name, grid) -> result + metrics
    gui/                   (empty) Member 4: Pygame GUI goes here

## Contract for the GUI (Member 4)
    from utils.metrics import run_algorithm
    result = run_algorithm("A*", grid)
    result["visited_order"]  # animate these cells one by one (light blue)
    result["path"]           # then draw in yellow and move the robot along it
    result["metrics"]        # show in the comparison panel
Terrain costs: Road 1, Grass 2, Mud 5, Water 8, Wall = blocked.
