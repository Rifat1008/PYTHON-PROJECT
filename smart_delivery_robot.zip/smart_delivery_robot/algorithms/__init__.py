from algorithms.bfs import bfs
from algorithms.dfs import dfs
from algorithms.ucs import ucs
from algorithms.greedy import greedy
from algorithms.astar import astar

# The GUI (Member 4) uses this dictionary to build the algorithm buttons.
ALGORITHMS = {
    "BFS": bfs,
    "DFS": dfs,
    "UCS": ucs,
    "Greedy": greedy,
    "A*": astar,
}
