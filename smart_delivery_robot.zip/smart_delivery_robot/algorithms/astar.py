"""
algorithms/astar.py  -- MEMBER 3
A* Search: priority = f = g + h
    g = real cost paid so far (terrain costs)
    h = Manhattan distance to goal
Manhattan is admissible here because the cheapest cell costs 1, so A* returns
the same optimal cost as UCS but usually explores fewer nodes.
"""
import heapq
from algorithms.common import manhattan, reconstruct_path, make_result


def astar(grid, start, goal):
    counter = 0
    frontier = [(manhattan(start, goal), counter, start)]   # (f, tie, node)
    parent = {start: None}
    best_g = {start: 0}
    closed = set()
    visited_order = []

    while frontier:
        _, _, current = heapq.heappop(frontier)
        if current in closed:
            continue
        closed.add(current)
        visited_order.append(current)

        if current == goal:
            return make_result(True, reconstruct_path(parent, start, goal), visited_order)

        for nxt in grid.neighbors(current):
            new_g = best_g[current] + grid.cost(nxt)
            if nxt not in best_g or new_g < best_g[nxt]:
                best_g[nxt] = new_g
                parent[nxt] = current
                counter += 1
                heapq.heappush(frontier, (new_g + manhattan(nxt, goal), counter, nxt))

    return make_result(False, [], visited_order)
