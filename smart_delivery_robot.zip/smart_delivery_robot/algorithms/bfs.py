"""
algorithms/bfs.py  -- MEMBER 1
Breadth First Search: explores level by level using a FIFO queue.
Finds the path with the FEWEST STEPS (ignores terrain cost).
"""
from collections import deque
from algorithms.common import reconstruct_path, make_result


def bfs(grid, start, goal):
    frontier = deque([start])
    parent = {start: None}          # also acts as the "seen" set
    visited_order = []

    while frontier:
        current = frontier.popleft()        # oldest node first (FIFO)
        visited_order.append(current)       # node is expanded

        if current == goal:
            return make_result(True, reconstruct_path(parent, start, goal), visited_order)

        for nxt in grid.neighbors(current):
            if nxt not in parent:           # not discovered yet
                parent[nxt] = current
                frontier.append(nxt)

    return make_result(False, [], visited_order)   # no path exists
