"""
algorithms/common.py
Helpers shared by all five algorithms so they all return the SAME result format.

Every algorithm returns a dict:
    {
      "found":         True / False,
      "path":          [(r,c), ...] from start to goal ([] if not found),
      "visited_order": [(r,c), ...] cells in the order they were EXPANDED
                       (the GUI animates this list),
    }
"nodes explored" = len(visited_order)  -> a node counts when it is expanded
(taken out of the frontier and its neighbours are generated). Same rule for all.
"""


def manhattan(a, b):
    """Manhattan distance heuristic used by Greedy and A*."""
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def reconstruct_path(parent, start, goal):
    """Walk back from goal to start using the parent dictionary."""
    path = [goal]
    while path[-1] != start:
        path.append(parent[path[-1]])
    path.reverse()
    return path


def make_result(found, path, visited_order):
    return {"found": found, "path": path, "visited_order": visited_order}
