"""
algorithms/dfs.py  -- MEMBER 1
Depth First Search: goes as deep as possible, then backtracks (LIFO stack).
Does NOT guarantee the shortest or cheapest path -- that is expected.
"""
from algorithms.common import reconstruct_path, make_result


def dfs(grid, start, goal):
    frontier = [(start, None)]      # stack of (node, parent)
    parent = {}
    visited = set()
    visited_order = []

    while frontier:
        current, par = frontier.pop()       # newest node first (LIFO)
        if current in visited:
            continue
        visited.add(current)
        parent[current] = par
        visited_order.append(current)       # node is expanded

        if current == goal:
            return make_result(True, reconstruct_path(parent, start, goal), visited_order)

        # reversed() so the first neighbour (up) is explored first
        for nxt in reversed(grid.neighbors(current)):
            if nxt not in visited:
                frontier.append((nxt, current))

    return make_result(False, [], visited_order)
