"""
algorithms/greedy.py  -- MEMBER 3
Greedy Best First Search: expands the node that LOOKS closest to the goal,
using only the Manhattan heuristic h. Fast, but may give a costly path.
"""
import heapq
from algorithms.common import manhattan, reconstruct_path, make_result


def greedy(grid, start, goal):
    counter = 0
    frontier = [(manhattan(start, goal), counter, start)]   # (h, tie, node)
    parent = {start: None}
    closed = set()
    visited_order = []

    while frontier:
        _, _, current = heapq.heappop(frontier)
        if current in closed:
            continue
        closed.add(current)
        visited_order.append(current)

        if current == goal:
            return make_result(True, reconstruct_path(parent, start, goal), visited_order)

        for nxt in grid.neighbors(current):
            if nxt not in parent:                # only the first discovery counts (no cost used)
                parent[nxt] = current
                counter += 1
                heapq.heappush(frontier, (manhattan(nxt, goal), counter, nxt))

    return make_result(False, [], visited_order)
