"""
algorithms/ucs.py  -- MEMBER 2
Uniform Cost Search: always expands the node with the LOWEST total cost g
so far (priority queue). Guarantees the minimum-cost path with terrain costs.
"""
import heapq
from algorithms.common import reconstruct_path, make_result


def ucs(grid, start, goal):
    counter = 0                                  # tie-breaker so heap never compares nodes
    frontier = [(0, counter, start)]             # (g, tie, node)
    parent = {start: None}
    best_g = {start: 0}
    closed = set()
    visited_order = []

    while frontier:
        g, _, current = heapq.heappop(frontier)
        if current in closed:                    # stale (older, costlier) entry
            continue
        closed.add(current)
        visited_order.append(current)            # node is expanded

        if current == goal:
            return make_result(True, reconstruct_path(parent, start, goal), visited_order)

        for nxt in grid.neighbors(current):
            new_g = g + grid.cost(nxt)
            if nxt not in best_g or new_g < best_g[nxt]:   # found a cheaper way
                best_g[nxt] = new_g
                parent[nxt] = current
                counter += 1
                heapq.heappush(frontier, (new_g, counter, nxt))

    return make_result(False, [], visited_order)
