"""
core/grid_model.py  (shared by ALL members)

The grid "world" the robot lives in. It contains NO Pygame code, so every
algorithm can be tested from the console. Member 4's GUI will draw this model.
"""

# ---- Terrain codes and their movement costs (cost of ENTERING the cell) ----
ROAD = 0    # cost 1
WALL = 1    # blocked (cannot be entered)
GRASS = 2   # cost 2
MUD = 3     # cost 5
WATER = 4   # cost 8

TERRAIN_COST = {ROAD: 1, GRASS: 2, MUD: 5, WATER: 8}
TERRAIN_NAMES = {ROAD: "Road", WALL: "Wall", GRASS: "Grass", MUD: "Mud", WATER: "Water"}


class Grid:
    def __init__(self, rows=20, cols=30):
        self.rows = rows
        self.cols = cols
        self.cells = [[ROAD for _ in range(cols)] for _ in range(rows)]
        self.start = (1, 1)                 # (row, col)
        self.goal = (rows - 2, cols - 2)

    # ---------- basic queries ----------
    def in_bounds(self, pos):
        r, c = pos
        return 0 <= r < self.rows and 0 <= c < self.cols

    def is_walkable(self, pos):
        return self.in_bounds(pos) and self.cells[pos[0]][pos[1]] != WALL

    def cost(self, pos):
        """Cost of moving INTO this cell."""
        return TERRAIN_COST[self.cells[pos[0]][pos[1]]]

    def neighbors(self, pos):
        """4-directional walkable neighbours (up, right, down, left).
        Every algorithm uses this same function, so the comparison is fair."""
        r, c = pos
        result = []
        for dr, dc in ((-1, 0), (0, 1), (1, 0), (0, -1)):
            nxt = (r + dr, c + dc)
            if self.is_walkable(nxt):
                result.append(nxt)
        return result

    # ---------- editing (used by the GUI) ----------
    def set_cell(self, pos, terrain):
        if not self.in_bounds(pos) or pos in (self.start, self.goal):
            return
        self.cells[pos[0]][pos[1]] = terrain

    def set_start(self, pos):
        if self.is_walkable(pos) and pos != self.goal:
            self.start = pos

    def set_goal(self, pos):
        if self.is_walkable(pos) and pos != self.start:
            self.goal = pos

    def clear(self):
        """Remove all walls/terrain but keep start and goal."""
        self.cells = [[ROAD for _ in range(self.cols)] for _ in range(self.rows)]

    def randomize(self, wall_chance=0.22, terrain_chance=0.18):
        import random
        for r in range(self.rows):
            for c in range(self.cols):
                x = random.random()
                if x < wall_chance:
                    self.cells[r][c] = WALL
                elif x < wall_chance + terrain_chance:
                    self.cells[r][c] = random.choice([GRASS, MUD, WATER])
                else:
                    self.cells[r][c] = ROAD
        self.cells[self.start[0]][self.start[1]] = ROAD
        self.cells[self.goal[0]][self.goal[1]] = ROAD
