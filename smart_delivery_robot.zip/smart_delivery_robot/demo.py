"""
demo.py -- shows all 5 algorithms visually in the terminal (for the 40% demo).
Run:
    python demo.py            (fixed demo map)
    python demo.py random     (random map)
Press Enter to go to the next algorithm.
"""
import os
import sys
import random
from core.grid_model import Grid, ROAD, WALL, GRASS, MUD, WATER
from algorithms import ALGORITHMS
from utils.metrics import run_algorithm

os.system("")  # enables colors in Windows cmd

# ---- fixed demo map: S=start G=goal #=wall g=grass m=mud w=water ----
DEMO_MAP = [
    "S.........#.........g.......",
    "..........#.........g.......",
    "....mmmm..#...##....ggg.....",
    "....mmmm..#...##............",
    "....mmmm......##..wwww......",
    "..........#...##..wwww......",
    "..........#.......wwww......",
    "......#####..###............",
    "......#.........#...mmm.....",
    "......#..gggg...#...mmm.....",
    "..........gggg..........#...",
    ".....................#....G.",
]
CODES = {".": ROAD, "#": WALL, "g": GRASS, "m": MUD, "w": WATER}

RESET = "\033[0m"
BG = {ROAD: "\033[48;5;252m", WALL: "\033[48;5;16m", GRASS: "\033[48;5;107m",
      MUD: "\033[48;5;94m", WATER: "\033[48;5;32m"}
VISITED = "\033[48;5;117m"
PATH = "\033[48;5;226m\033[30m"
START = "\033[48;5;34m\033[97m"
GOAL = "\033[48;5;196m\033[97m"


def build_demo_grid():
    g = Grid(len(DEMO_MAP), len(DEMO_MAP[0]))
    for r, line in enumerate(DEMO_MAP):
        for c, ch in enumerate(line):
            if ch == "S":
                g.start = (r, c)
            elif ch == "G":
                g.goal = (r, c)
            else:
                g.cells[r][c] = CODES[ch]
    return g


def draw(grid, result):
    visited = set(result["visited_order"])
    path = set(result["path"])
    for r in range(grid.rows):
        line = ""
        for c in range(grid.cols):
            p = (r, c)
            if p == grid.start:
                line += START + " S " + RESET
            elif p == grid.goal:
                line += GOAL + " G " + RESET
            elif p in path:
                line += PATH + " * " + RESET
            elif p in visited:
                line += VISITED + " . " + RESET
            else:
                line += BG[grid.cells[r][c]] + "   " + RESET
        print(line)


def main():
    if len(sys.argv) > 1 and sys.argv[1] == "random":
        grid = Grid(12, 28)
        grid.randomize()
    else:
        grid = build_demo_grid()

    print("\nLegend: S=Start  G=Goal  black=Wall  grey=Road(1)  green=Grass(2)  brown=Mud(5)  blue=Water(8)")
    print("        light-blue '.'=Visited  yellow '*'=Final path\n")
    rows = []
    for name in ALGORITHMS:
        res = run_algorithm(name, grid)
        m = res["metrics"]
        rows.append(m)
        print(f"===== {name} =====")
        draw(grid, res)
        print(f"Found: {m['found']} | Nodes explored: {m['nodes_explored']} | "
              f"Path length: {m['path_length']} | Path cost: {m['path_cost']} | Time: {m['time_ms']} ms\n")
        input("Press Enter for next algorithm...")
        print()

    print("===== COMPARISON =====")
    print(f"{'Algorithm':<10}{'Found':<8}{'Explored':<10}{'Steps':<8}{'Cost':<8}{'Time(ms)'}")
    for m in rows:
        print(f"{m['algorithm']:<10}{str(m['found']):<8}{m['nodes_explored']:<10}{m['path_length']:<8}{m['path_cost']:<8}{m['time_ms']}")


if __name__ == "__main__":
    main()
