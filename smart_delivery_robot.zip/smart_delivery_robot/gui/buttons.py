"""
gui/buttons.py
A small reusable Button class for the Pygame interface.
"""
import pygame


class Button:
    def __init__(self, rect, text, color=(58, 64, 82), text_color=(235, 238, 245)):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.color = color
        self.text_color = text_color
        self.active = False          # highlighted (selected algorithm / brush)

    def draw(self, surface, font, mouse_pos):
        hover = self.rect.collidepoint(mouse_pos)
        base = self.color
        if self.active:
            base = (70, 130, 230)
        elif hover:
            base = tuple(min(255, v + 18) for v in base)
        pygame.draw.rect(surface, base, self.rect, border_radius=8)
        if self.active:
            pygame.draw.rect(surface, (180, 210, 255), self.rect, width=2, border_radius=8)
        label = font.render(self.text, True, self.text_color)
        surface.blit(label, label.get_rect(center=self.rect.center))

    def hit(self, pos):
        return self.rect.collidepoint(pos)
