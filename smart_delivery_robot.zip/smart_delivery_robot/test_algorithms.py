"""
test_algorithms.py -- run this in the terminal (no Pygame needed):
    python test_algorithms.py
Checks all five algorithms on random maps and prints a comparison table.
"""
import random
from core.grid_model import Grid
from algorithms import ALGORITHMS
from utils.metrics import run_algorithm


def valid(grid, path):
    if path[0] != grid.start or path[-1] != grid.goal:
        return False
    for a, b in zip(path, path[1:]):
        if b not in grid.neighbors(a):          # also guarantees no wall is crossed
            return False
    return True


def main():
    random.seed(7)
    for trial in range(200):
        g = Grid(15, 20)
        g.randomize()
        res = {n: run_algorithm(n, g) for n in ALGORITHMS}

        founds = {r["found"] for r in res.values()}
        assert len(founds) == 1, "algorithms disagree about path existence"
        if not res["BFS"]["found"]:
            continue
        for n, r in res.items():
            assert valid(g, r["path"]), f"{n} gave an invalid path"
        m = {n: r["metrics"] for n, r in res.items()}
        assert m["UCS"]["path_cost"] == m["A*"]["path_cost"], "UCS and A* must have equal optimal cost"
        assert m["UCS"]["path_cost"] <= min(x["path_cost"] for x in m.values())
        assert m["BFS"]["path_length"] <= min(x["path_length"] for x in m.values())
    print("All 200 random-map checks passed.\n")

    random.seed(3)
    g = Grid(15, 20)
    g.randomize()
    print(f"{'Algorithm':<8}{'Found':<7}{'Explored':<10}{'Steps':<7}{'Cost':<7}{'Time(ms)'}")
    for n in ALGORITHMS:
        m = run_algorithm(n, g)["metrics"]
        print(f"{n:<8}{str(m['found']):<7}{m['nodes_explored']:<10}{m['path_length']:<7}{m['path_cost']:<7}{m['time_ms']}")


if __name__ == "__main__":
    main()
