"""
utils/metrics.py
Runs ANY algorithm on a grid and calculates the comparison metrics the same
way for every algorithm (fair comparison).
"""
import time
from algorithms import ALGORITHMS


def path_cost(grid, path):
    """Total cost = sum of the terrain cost of every cell ENTERED (start excluded)."""
    return sum(grid.cost(p) for p in path[1:])


def run_algorithm(name, grid):
    """Returns the algorithm result plus metrics."""
    func = ALGORITHMS[name]

    t0 = time.perf_counter()
    result = func(grid, grid.start, grid.goal)      # only the search itself is timed
    elapsed_ms = (time.perf_counter() - t0) * 1000

    result["metrics"] = {
        "algorithm": name,
        "nodes_explored": len(result["visited_order"]),
        "path_length": max(len(result["path"]) - 1, 0) if result["found"] else 0,  # steps
        "path_cost": path_cost(grid, result["path"]) if result["found"] else 0,
        "time_ms": round(elapsed_ms, 3),
        "found": result["found"],
    }
    return result
